﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using workerServiceCoinAlSat.Services.Interfaces;

namespace workerServiceCoinAlSat.Services.Implementation
{
    public class AlSatControlService : IAlSatControlService
    {
        public AlSatControlService() { }

        public void test()
        {
            
            Console.WriteLine("test");
        }
    }
}
