﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace workerServiceCoinAlSat.Services.Interfaces
{
    public interface IAlSatControlService
    {
        void test();
    }
}
