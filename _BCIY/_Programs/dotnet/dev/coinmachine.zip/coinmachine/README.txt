dotnet ef dbcontext scaffold "Server=.;Database=coins;User Id=cengiz;Password=sifre;MultipleActiveResultSets=true;TrustServerCertificate=True" Microsoft.EntityFrameworkCore.SqlServer


dotnet ef dbcontext scaffold "Server=51.12.247.74;Database=coins;User Id=bciy;Password=bciy!957;MultipleActiveResultSets=true;TrustServerCertificate=True" Microsoft.EntityFrameworkCore.SqlServer