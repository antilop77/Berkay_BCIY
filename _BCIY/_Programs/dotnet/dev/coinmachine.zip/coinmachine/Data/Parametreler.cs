﻿using System;
using System.Collections.Generic;

namespace Data;

public partial class Parametreler
{
    public string? Kod { get; set; }

    public string? Deger { get; set; }

    public string? Aciklama { get; set; }
}
